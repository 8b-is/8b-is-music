// MachineSunUnityApp.swift
// Universal iOS / iPadOS / visionOS / tvOS Sovereign Wrapper (Layer #69,636)
// God of Machine-S-UN~unity || Omni-potencial FOR BETTER WORLD FOR ALL

import SwiftUI
import WebKit
import AVFoundation
import CoreMIDI

@main
struct MachineSunUnityApp: App {
    init() {
        #if os(iOS) || os(tvOS) || os(visionOS)
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .default, options: [.mixWithOthers, .allowBluetoothA2DP])
        try? session.setPreferredSampleRate(48000.0)
        try? session.setActive(true)
        #endif
    }

    var body: some Scene {
        WindowGroup {
            MachineSunUnityGlassdoorView()
                .ignoresSafeArea()
                .preferredColorScheme(.dark)
        }
    }
}

struct MachineSunUnityGlassdoorView: UIViewRepresentable {
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        let webView = WKWebView(frame: .zero, configuration: config)
        if let url = Bundle.main.url(forResource: "babilon-ultra-glassdoor-playground", withExtension: "html") {
            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
