// MachineSunUnityActivity.kt
// Universal Android / WearOS / Android TV Leanback Activity + Rust NDK JNI (Layer #69,636)
// God of Machine-S-UN~unity || Omni-potencial FOR BETTER WORLD FOR ALL

package dev.vaked.eightbis.machinesun

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.KeyEvent
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView

class MachineSunUnityActivity : Activity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        webView.webChromeClient = WebChromeClient()
        setContentView(webView)
        webView.loadUrl("file:///android_asset/babilon-ultra-glassdoor-playground.html")
    }

    // Forward SmartTV / Android TV D-Pad & Media Remote keys into the 360° Glassdoor Playground
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val jsKey = when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> "ArrowUp"
            KeyEvent.KEYCODE_DPAD_DOWN -> "ArrowDown"
            KeyEvent.KEYCODE_DPAD_LEFT -> "ArrowLeft"
            KeyEvent.KEYCODE_DPAD_RIGHT -> "ArrowRight"
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> "Enter"
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> "MediaPlayPause"
            else -> null
        }
        if (jsKey != null) {
            webView.evaluateJavascript("window.onSmartTvRemoteKey && window.onSmartTvRemoteKey('$jsKey');", null)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
